#include "pch.h"
extern int ans;

int sub1(int a, int b)
{
	ans = a - b;
	return ans;
}